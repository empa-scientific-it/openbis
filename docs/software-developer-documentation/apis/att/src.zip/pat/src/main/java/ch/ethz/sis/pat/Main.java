package ch.ethz.sis.pat;

import ch.ethz.sis.openbis.generic.asapi.v3.IApplicationServerApi;
import ch.ethz.sis.openbis.generic.asapi.v3.dto.pat.id.PersonalAccessTokenPermId;
import ch.systemsx.cisd.common.spring.HttpInvokerUtils;

public class Main {

    private static final String URL = "https://openbis-sis-ci-sprint.ethz.ch/openbis/openbis" + IApplicationServerApi.SERVICE_URL;
    private static final int TIMEOUT = 10000;

    private static final String USER = "admin";
    private static final String PASSWORD = "changeit";

    public static void main(String[] args) {
        IApplicationServerApi v3 = HttpInvokerUtils.createServiceStub(IApplicationServerApi.class, URL, TIMEOUT);
        String sessionToken = v3.login(USER, PASSWORD);
        System.out.println("sessionToken: " + sessionToken);
        PersonalAccessTokenPermId pat = PersonalAccessTokensApplicationWorkflows.getApplicationPersonalAccessTokenOnLogin(v3, sessionToken, "MY_APPLICATION");
        System.out.println("pat: " + pat);
        v3.logout(sessionToken);
    }
}
