# PAT #

## Introduction ##

Project created to practice with the personal access token API.

## Build ##

./gradlew distZip

The build will be found at ./build/distributions/pat.zip

## Usage ##




