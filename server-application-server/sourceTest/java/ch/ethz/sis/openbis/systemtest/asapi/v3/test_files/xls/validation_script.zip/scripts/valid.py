print 'Test validation script'
